// Libs
// var request = require('request');
// var cheerio = require('cheerio');
// var Crawler = require("crawler");
// Connect Db
// var dbName = 'job-sjb';
// var strConnection = 'mongodb://127.0.0.1:27017/' + dbName;
// var Epl = require('./models/Site-2/Employer');
// var Jb = require('./models/Site-2/Job');
// var helper = require('./helper');
// var mongoose = require('mongoose');
// mongoose.Promise = global.Promise;
// mongoose.connect(strConnection);